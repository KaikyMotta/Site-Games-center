package br.edu.qi.projagamescenter;

public class UsuarioDAO {

}
